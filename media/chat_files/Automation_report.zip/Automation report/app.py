from flask import Flask, send_file, request, abort
import os

app = Flask(__name__)

# Folder where your excel files are stored
REPORT_FOLDER = "reports"


@app.route('/download-report')
def download_report():
    file_name = request.args.get('file')

    if not file_name:
        return "Please provide file name", 400

    file_path = os.path.join(REPORT_FOLDER, file_name)

    # सुरक्षा check (file exists or not)
    if not os.path.exists(file_path):
        return "File not found", 404

    return send_file(file_path, as_attachment=True)


if __name__ == '__main__':
    app.run(debug=True)